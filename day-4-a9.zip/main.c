/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
union Student
{
    char name[50];
    float gpa;
};
int main() {
    union Student student;
    printf("Enter the student's name: ");
    scanf("%s", student.name);
    printf("Enter the student's GPA: ");
    scanf("%f", &student.gpa);
    printf("Student's name: %s\n", student.name);
    printf("Student's GPA: %f\n", student.gpa);
    return 0;
}